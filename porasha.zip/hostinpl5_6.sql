-- phpMyAdmin SQL Dump
-- version 4.6.6deb4+deb9u1
-- http://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Ноя 10 2020 г., 17:38
-- Версия сервера: 10.1.45-MariaDB-0+deb9u1
-- Версия PHP: 7.0.33-0+deb9u10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `hostinpl5.6`
--

-- --------------------------------------------------------

--
-- Структура таблицы `authlog`
--

CREATE TABLE `authlog` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `ip` varchar(64) NOT NULL,
  `city` text NOT NULL,
  `country` text NOT NULL,
  `code` text NOT NULL,
  `datetime` datetime NOT NULL,
  `status` int(1) NOT NULL,
  `password` text NOT NULL,
  `system` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `games`
--

CREATE TABLE `games` (
  `game_id` int(10) NOT NULL,
  `game_name` varchar(92) DEFAULT NULL,
  `game_code` varchar(8) DEFAULT NULL,
  `game_query` varchar(32) DEFAULT NULL,
  `game_min_slots` int(8) DEFAULT NULL,
  `game_max_slots` int(8) DEFAULT NULL,
  `game_min_port` int(8) DEFAULT NULL,
  `game_max_port` int(8) DEFAULT NULL,
  `game_cores` decimal(10,2) NOT NULL DEFAULT '1.00',
  `game_ram` int(64) NOT NULL DEFAULT '1024',
  `game_ssd` varchar(128) NOT NULL DEFAULT '512',
  `game_price` decimal(10,2) DEFAULT NULL,
  `game_status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `games`
--

INSERT INTO `games` (`game_id`, `game_name`, `game_code`, `game_query`, `game_min_slots`, `game_max_slots`, `game_min_port`, `game_max_port`, `game_cores`, `game_ram`, `game_ssd`, `game_price`, `game_status`) VALUES
(1, 'San Andreas: Multiplayer 0.3.7', 'samp', 'samp', 50, 1000, 7777, 9999, '0.45', 512, '250', '1.00', 0),
(2, 'Criminal Russia: Multiplayer 0.3e', 'crmp', 'samp', 50, 500, 3335, 7000, '0.45', 512, '250', '1.00', 0),
(3, 'Criminal Russia: Multiplayer 0.3.7', 'crmp037', 'samp', 50, 500, 3335, 7000, '0.45', 512, '250', '1.00', 0),
(4, 'United Multiplayer', 'unit', 'samp', 50, 500, 7777, 9999, '0.45', 512, '250', '1.00', 0),
(5, 'Multi Theft Auto: Multiplayer', 'mta', 'mtasa', 50, 1000, 25020, 80520, '0.60', 512, '500', '1.00', 0),
(6, 'MineCraft: PE', 'mcpe', 'mine', 10, 100, 12410, 55641, '1.00', 1024, '750', '5.00', 0),
(7, 'MineCraft', 'mine', 'mine', 10, 100, 12410, 55641, '1.00', 1024, '750', '5.00', 0),
(8, 'Counter-Strike: 1.6', 'cs', 'valve', 6, 32, 27016, 30550, '1.00', 1024, '2500', '4.00', 0),
(9, 'Counter-Strike: Source', 'css', 'valve', 6, 32, 27016, 30550, '1.00', 1024, '6500', '8.00', 0),
(10, 'Counter-Strike: GO', 'csgo', 'valve', 6, 32, 27016, 30550, '2.00', 1512, '35000', '25.00', 0),
(11, 'GTA V: RAGE MP (NodeJS + MySQL)', 'ragemp', 'ragemp', 50, 500, 22000, 25000, '0.95', 1024, '2500', '4.00', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `inbox`
--

CREATE TABLE `inbox` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_firstname` varchar(15) NOT NULL,
  `user_lastname` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  `text` text,
  `status` int(1) NOT NULL,
  `inbox_date_add` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `invoices`
--

CREATE TABLE `invoices` (
  `invoice_id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `invoice_ammount` decimal(10,2) DEFAULT NULL,
  `invoice_status` int(1) DEFAULT NULL,
  `invoice_date_add` datetime DEFAULT NULL,
  `system` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `locations`
--

CREATE TABLE `locations` (
  `location_id` int(10) NOT NULL,
  `location_name` varchar(32) DEFAULT NULL,
  `location_ip` varchar(15) DEFAULT NULL,
  `location_ip2` varchar(15) DEFAULT NULL,
  `location_user` varchar(32) DEFAULT NULL,
  `location_password` varchar(32) DEFAULT NULL,
  `location_status` int(1) DEFAULT NULL,
  `location_cpu` varchar(128) NOT NULL DEFAULT '0',
  `location_ram` varchar(128) NOT NULL DEFAULT '0',
  `location_hdd` varchar(128) NOT NULL DEFAULT '0',
  `location_upd` datetime NOT NULL,
  `location_games` varchar(98) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `locations_stats`
--

CREATE TABLE `locations_stats` (
  `location_id` int(11) DEFAULT NULL,
  `location_stats_date` datetime DEFAULT NULL,
  `location_stats_cpu` int(11) NOT NULL,
  `location_stats_ram` int(11) NOT NULL,
  `location_stats_hdd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
-- --------------------------------------------------------


--
-- Структура таблицы `news`
--

CREATE TABLE `news` (
  `news_id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT '0',
  `news_title` varchar(100) DEFAULT NULL,
  `news_text` text NOT NULL,
  `news_date_add` datetime DEFAULT NULL,
  `look` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `news_messages`
--

CREATE TABLE `news_messages` (
  `news_message_id` int(10) NOT NULL,
  `news_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `news_message` text,
  `news_message_date_add` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `promo`
--

CREATE TABLE `promo` (
  `id` int(11) NOT NULL,
  `cod` text,
  `uses` int(11) DEFAULT NULL,
  `used` int(11) DEFAULT NULL,
  `skidka` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `serverlog`
--

CREATE TABLE `serverlog` (
  `log_id` int(11) NOT NULL,
  `reason` text CHARACTER SET utf8 NOT NULL,
  `status` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `server_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `servers`
--

CREATE TABLE `servers` (
  `server_id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `game_id` int(10) DEFAULT NULL,
  `location_id` int(10) DEFAULT NULL,
  `server_slots` int(8) DEFAULT NULL,
  `server_port` int(8) DEFAULT NULL,
  `server_password` varchar(32) DEFAULT NULL,
  `server_status` int(1) DEFAULT NULL,
  `server_work` int(11) DEFAULT NULL,
  `server_date_reg` datetime DEFAULT NULL,
  `server_date_end` datetime DEFAULT NULL,
  `db_pass` varchar(32) DEFAULT NULL,
  `server_mysql` int(11) DEFAULT NULL,
  `fastdl_status` int(11) NOT NULL,
  `server_fps` int(10) DEFAULT '0',
  `server_tickrate` int(10) NOT NULL DEFAULT '0',
  `server_vac` int(10) NOT NULL DEFAULT '0',
  `server_binary` varchar(96) DEFAULT NULL,
  `server_binary_version` varchar(38) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `servers_firewalls`
--

CREATE TABLE `servers_firewalls` (
  `firewall_id` int(10) NOT NULL,
  `server_id` int(8) DEFAULT NULL,
  `server_ip` text,
  `firewall_add` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `servers_mods`
--

CREATE TABLE `servers_mods` (
  `game_id` int(11) DEFAULT NULL,
  `mod_url` text CHARACTER SET utf8 NOT NULL,
  `mod_name` text CHARACTER SET utf8 NOT NULL,
  `mod_status` int(11) DEFAULT NULL,
  `mod_arch` text CHARACTER SET utf8 NOT NULL,
  `mod_textx` text CHARACTER SET utf8 NOT NULL,
  `mod_img` text CHARACTER SET utf8 NOT NULL,
  `mod_price` text,
  `mod_set` int(1) NOT NULL,
  `mod_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `servers_mods`
--

INSERT INTO `servers_mods` (`game_id`, `mod_url`, `mod_name`, `mod_status`, `mod_arch`, `mod_textx`, `mod_img`, `mod_price`, `mod_set`, `mod_id`) VALUES
(1, 'https://host.ru', 'RUSSIA-RP (2022)', 1, 'russia-rp.tar', 'Обновленый мод в бонусном режиме, очень много крутых систем/маппинг', 'https://i.ytimg.com/vi/nZPcdoZkUGE/maxresdefault.jpg', '20', 0, 4),
(1, 'https://host.ru', 'YouTube-RP (2022)', 1, 'youtube-rp.tar', 'Обновленый мод, подходит для бонусного сервера, текстдравы и много чего есть.', 'https://i.ytimg.com/vi/FSZ6lKhixJA/maxresdefault.jpg', '25', 0, 5),
(1, 'https://host.ru', 'Heavily-RP (2021)\n', 1, 'heavily-rp.tar', 'Отличный игровой мод бонусном режиме, подойдет под открытие', 'https://gnr-samp.ucoz.ru/_ld/5/67087859.jpg', '0', 0, 6),
(1, 'https://host.ru', 'Arizona-RP (Miking)', 1, 'arizona-rp-miking.tar', 'Мод очень крутой, в моде есть самые новые люксы/скины/аксы новый спавн и много много чего', 'https://i.ytimg.com/vi/KkfaX1pgC_Q/maxresdefault.jpg', '40', 0, 7);

-- --------------------------------------------------------

--
-- Структура таблицы `servers_owners`
--

CREATE TABLE `servers_owners` (
  `owner_id` int(10) NOT NULL,
  `server_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `owner_status` int(11) NOT NULL,
  `owner_add` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `servers_repo`
--

CREATE TABLE `servers_repo` (
  `game_id` int(11) DEFAULT NULL,
  `repo_url` text CHARACTER SET utf8 NOT NULL,
  `repo_name` text CHARACTER SET utf8 NOT NULL,
  `repo_status` int(11) DEFAULT NULL,
  `repo_textx` text CHARACTER SET utf8 NOT NULL,
  `repo_img` text CHARACTER SET utf8 NOT NULL,
  `repo_price` text,
  `repo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `servers_stats`
--

CREATE TABLE `servers_stats` (
  `server_id` int(11) DEFAULT NULL,
  `server_stats_date` datetime DEFAULT NULL,
  `server_stats_players` int(11) DEFAULT NULL,
  `server_stats_cpu` int(11) NOT NULL,
  `server_stats_ram` int(11) NOT NULL,
  `server_stats_hdd` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `servers_tasks`
--

CREATE TABLE `servers_tasks` (
  `task_id` bigint(255) NOT NULL,
  `server_id` bigint(255) NOT NULL,
  `task_name` text CHARACTER SET cp1251 NOT NULL,
  `task_type` text CHARACTER SET cp1251 NOT NULL,
  `task_time` text CHARACTER SET cp1251 NOT NULL,
  `task_lead_time` datetime NOT NULL,
  `task_status` int(11) NOT NULL,
  `isSystemTask` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `ticket_name` varchar(32) DEFAULT NULL,
  `ticket_status` int(1) DEFAULT NULL,
  `ticket_date_add` datetime DEFAULT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `tickets_category`
--

CREATE TABLE `tickets_category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `category_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `tickets_messages`
--

CREATE TABLE `tickets_messages` (
  `ticket_message_id` int(10) NOT NULL,
  `ticket_id` int(10) DEFAULT NULL,
  `user_id` int(10) DEFAULT NULL,
  `ticket_message` text,
  `ticket_message_date_add` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `user_email` varchar(96) DEFAULT NULL,
  `user_new_email` varchar(256) DEFAULT NULL,
  `user_password` varchar(32) DEFAULT NULL,
  `user_firstname` varchar(32) DEFAULT NULL,
  `user_lastname` varchar(32) DEFAULT NULL,
  `user_status` int(1) DEFAULT NULL,
  `user_balance` decimal(10,2) DEFAULT NULL,
  `user_restore_key` varchar(32) DEFAULT NULL,
  `user_access_level` int(1) DEFAULT NULL,
  `user_date_reg` datetime DEFAULT NULL,
  `user_img` varchar(250) NOT NULL DEFAULT 'application/public/img/user.png',
  `user_online_date` text NOT NULL,
  `user_promo_date` date NOT NULL,
  `user_activate` int(1) NOT NULL,
  `key_activate` text NOT NULL,
  `ref` int(11) NOT NULL,
  `rmoney` decimal(10,2) DEFAULT NULL,
  `bonuses` decimal(10,2) DEFAULT '0.00',
  `user_vk_id` varchar(96) DEFAULT NULL,
  `test_server` varchar(2) NOT NULL DEFAULT '2',
  `user_promised_pay` int(11) NOT NULL DEFAULT '0',
  `user_last_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `users_auth`
--

CREATE TABLE `users_auth` (
  `auth_id` bigint(255) NOT NULL,
  `user_id` bigint(255) NOT NULL,
  `user_ip` text CHARACTER SET cp1251 NOT NULL,
  `user_last_activity` datetime NOT NULL,
  `auth_user_email` longtext CHARACTER SET cp1251 NOT NULL,
  `auth_user_password` longtext CHARACTER SET cp1251 NOT NULL,
  `auth_type` text CHARACTER SET cp1251 NOT NULL,
  `auth_key` longtext NOT NULL,
  `auth_date_add` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `users_mods`
--

CREATE TABLE `users_mods` (
  `id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `mod_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `users_repo`
--

CREATE TABLE `users_repo` (
  `id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `repo_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `waste`
--

CREATE TABLE `waste` (
  `waste_id` int(10) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `waste_ammount` decimal(10,2) DEFAULT NULL,
  `waste_status` int(1) DEFAULT NULL,
  `waste_usluga` varchar(120) DEFAULT NULL,
  `waste_date_add` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `webhost`
--

CREATE TABLE `webhost` (
  `web_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `tarif_id` int(11) DEFAULT NULL,
  `web_password` varchar(32) NOT NULL,
  `web_domain` varchar(32) NOT NULL,
  `web_status` int(11) NOT NULL,
  `web_date_reg` datetime DEFAULT NULL,
  `web_date_end` datetime DEFAULT NULL,
  `location_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Структура таблицы `web_locations`
--

CREATE TABLE `web_locations` (
  `location_id` int(10) NOT NULL,
  `location_name` varchar(32) DEFAULT NULL,
  `location_ip` varchar(15) DEFAULT NULL,
  `location_url` varchar(45) DEFAULT NULL,
  `location_user` varchar(32) DEFAULT NULL,
  `location_password` varchar(32) DEFAULT NULL,
  `ns_servers` text NOT NULL,
  `location_status` int(1) DEFAULT NULL,
  `location_tarifs` varchar(98) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `web_tarifs`
--

CREATE TABLE `web_tarifs` (
  `tarif_id` int(150) NOT NULL,
  `tarif_name` varchar(32) CHARACTER SET utf8 NOT NULL,
  `package` varchar(32) CHARACTER SET utf8 NOT NULL,
  `tarif_price` decimal(10,2) NOT NULL,
  `tarif_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `authlog`
--
ALTER TABLE `authlog`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`game_id`);

--
-- Индексы таблицы `inbox`
--
ALTER TABLE `inbox`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`invoice_id`);

--
-- Индексы таблицы `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Индексы таблицы `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`news_id`);

--
-- Индексы таблицы `news_messages`
--
ALTER TABLE `news_messages`
  ADD PRIMARY KEY (`news_message_id`);

--
-- Индексы таблицы `promo`
--
ALTER TABLE `promo`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `serverlog`
--
ALTER TABLE `serverlog`
  ADD PRIMARY KEY (`log_id`);

--
-- Индексы таблицы `servers`
--
ALTER TABLE `servers`
  ADD PRIMARY KEY (`server_id`);

--
-- Индексы таблицы `servers_firewalls`
--
ALTER TABLE `servers_firewalls`
  ADD PRIMARY KEY (`firewall_id`);

--
-- Индексы таблицы `servers_mods`
--
ALTER TABLE `servers_mods`
  ADD PRIMARY KEY (`mod_id`);

--
-- Индексы таблицы `servers_owners`
--
ALTER TABLE `servers_owners`
  ADD PRIMARY KEY (`owner_id`);

--
-- Индексы таблицы `servers_repo`
--
ALTER TABLE `servers_repo`
  ADD PRIMARY KEY (`repo_id`);

--
-- Индексы таблицы `servers_tasks`
--
ALTER TABLE `servers_tasks`
  ADD PRIMARY KEY (`task_id`);

--
-- Индексы таблицы `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Индексы таблицы `tickets_category`
--
ALTER TABLE `tickets_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Индексы таблицы `tickets_messages`
--
ALTER TABLE `tickets_messages`
  ADD PRIMARY KEY (`ticket_message_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Индексы таблицы `users_auth`
--
ALTER TABLE `users_auth`
  ADD PRIMARY KEY (`auth_id`);

--
-- Индексы таблицы `users_mods`
--
ALTER TABLE `users_mods`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users_repo`
--
ALTER TABLE `users_repo`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `waste`
--
ALTER TABLE `waste`
  ADD PRIMARY KEY (`waste_id`);

--
-- Индексы таблицы `webhost`
--
ALTER TABLE `webhost`
  ADD PRIMARY KEY (`web_id`);

--
-- Индексы таблицы `web_locations`
--
ALTER TABLE `web_locations`
  ADD PRIMARY KEY (`location_id`);

--
-- Индексы таблицы `web_tarifs`
--
ALTER TABLE `web_tarifs`
  ADD PRIMARY KEY (`tarif_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `authlog`
--
ALTER TABLE `authlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `games`
--
ALTER TABLE `games`
  MODIFY `game_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT для таблицы `inbox`
--
ALTER TABLE `inbox`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `invoices`
--
ALTER TABLE `invoices`
  MODIFY `invoice_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `locations`
--
ALTER TABLE `locations`
  MODIFY `location_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `news`
--
ALTER TABLE `news`
  MODIFY `news_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `news_messages`
--
ALTER TABLE `news_messages`
  MODIFY `news_message_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `promo`
--
ALTER TABLE `promo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `serverlog`
--
ALTER TABLE `serverlog`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `servers`
--
ALTER TABLE `servers`
  MODIFY `server_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `servers_firewalls`
--
ALTER TABLE `servers_firewalls`
  MODIFY `firewall_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `servers_mods`
--
ALTER TABLE `servers_mods`
  MODIFY `mod_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT для таблицы `servers_owners`
--
ALTER TABLE `servers_owners`
  MODIFY `owner_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `servers_repo`
--
ALTER TABLE `servers_repo`
  MODIFY `repo_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `servers_tasks`
--
ALTER TABLE `servers_tasks`
  MODIFY `task_id` bigint(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `tickets_category`
--
ALTER TABLE `tickets_category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `tickets_messages`
--
ALTER TABLE `tickets_messages`
  MODIFY `ticket_message_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `users_auth`
--
ALTER TABLE `users_auth`
  MODIFY `auth_id` bigint(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `users_mods`
--
ALTER TABLE `users_mods`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `users_repo`
--
ALTER TABLE `users_repo`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `waste`
--
ALTER TABLE `waste`
  MODIFY `waste_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `webhost`
--
ALTER TABLE `webhost`
  MODIFY `web_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `web_locations`
--
ALTER TABLE `web_locations`
  MODIFY `location_id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `web_tarifs`
--
ALTER TABLE `web_tarifs`
  MODIFY `tarif_id` int(150) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
