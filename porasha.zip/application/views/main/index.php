
<?php echo $header ?>
<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
   <div class="d-flex flex-column-fluid">
      <div class="container">
<div class="row">
<div class="col-xl-6">
   <!--begin::Engage Widget 1-->
   <div class="card card-custom card-stretch gutter-b">
      <div class="card-body d-flex p-0">
         <div class="flex-grow-1 p-8 card-rounded bgi-no-repeat d-flex align-items-center" style="background-color: #FF0000; background-position: left bottom; background-size: auto 115%; background-image: url(/assets/gta-main/glavar.png)">
            <div class="row">
               <div class="col-12 col-xl-5"></div>
               <div class="col-12 col-xl-7">
                  <h4 class="text-inverse-danger font-weight-bolder">Удобная панель управления</h4>
                  <p class="text-inverse-danger my-5 font-size-xl font-weight-bold">С нашей панелью управления, управлять серверами легко и просто с ней справится как опытный пользователь так и новичок.</p>
               </div>
            </div>
         </div>
      </div>
   </div>
   <!--end::Engage Widget 1-->
</div>
<div class="col-xl-3">
   <!--begin::Engage Widget 2-->
   <div class="card card-custom card-stretch gutter-b">
      <div class="card-body d-flex p-0">
         <div class="flex-grow-1 p-8 card-rounded flex-grow-1 bgi-no-repeat" style="background-color: #FF0000; background-position: calc(100% + 0.5rem) bottom; background-size: auto 90%; background-image: url(/assets/gta-main/gandon.png)">
            <h4 class="text-inverse-danger mt-2 font-weight-bolder">Тех. поддержка</h4>
            <p class="text-inverse-danger my-6">Наша техническая поддержка работает "7" дней в неделю "24" часа в сутки "365" дней в году. Мы готовы помощь вам в любое время суток</p>
            <a href="/tickets/create" class="btn btn-white font-weight-bold py-2 px-6">Задать вопрос</a>
         </div>
      </div>
   </div>
   <!--end::Engage Widget 2-->
</div>
<div class="col-xl-3">
   <!--begin::Engage Widget 3-->
   <div class="card card-custom card-stretch gutter-b">
      <div class="card-body d-flex p-0 card-rounded">
         <div class="flex-grow-1 p-10 card-rounded flex-grow-1 bgi-no-repeat" style="background-color: #FF0000; background-position: calc(100% + 0.5rem) bottom; background-size: auto 90%; background-image: url(/assets/gta-main/trevor.png)">
            <h4 class="text-inverse-danger mt-2 font-weight-bolder">Наши услуги</h4>
            <div class="mt-5">
               <div class="d-flex mb-5">
                  <span class="svg-icon svg-icon-md svg-icon-white flex-shrink-0 mr-3">
                     <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Arrow-right.svg-->
                     <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                           <polygon points="0 0 24 0 24 24 0 24"></polygon>
                           <rect fill="#000000" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000)" x="11" y="5" width="2" height="14" rx="1"></rect>
                           <path d="M9.70710318,15.7071045 C9.31657888,16.0976288 8.68341391,16.0976288 8.29288961,15.7071045 C7.90236532,15.3165802 7.90236532,14.6834152 8.29288961,14.2928909 L14.2928896,8.29289093 C14.6714686,7.914312 15.281055,7.90106637 15.675721,8.26284357 L21.675721,13.7628436 C22.08284,14.136036 22.1103429,14.7686034 21.7371505,15.1757223 C21.3639581,15.5828413 20.7313908,15.6103443 20.3242718,15.2371519 L15.0300721,10.3841355 L9.70710318,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(14.999999, 11.999997) scale(1, -1) rotate(90.000000) translate(-14.999999, -11.999997)"></path>
                        </g>
                     </svg>
                     <!--end::Svg Icon-->
                  </span>
                  <span class="text-white">Хостинг GTA серверов</span>
               </div>
               <div class="d-flex mb-5">
                  <span class="svg-icon svg-icon-md svg-icon-white flex-shrink-0 mr-3">
                     <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Arrow-right.svg-->
                     <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                           <polygon points="0 0 24 0 24 24 0 24"></polygon>
                           <rect fill="#000000" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000)" x="11" y="5" width="2" height="14" rx="1"></rect>
                           <path d="M9.70710318,15.7071045 C9.31657888,16.0976288 8.68341391,16.0976288 8.29288961,15.7071045 C7.90236532,15.3165802 7.90236532,14.6834152 8.29288961,14.2928909 L14.2928896,8.29289093 C14.6714686,7.914312 15.281055,7.90106637 15.675721,8.26284357 L21.675721,13.7628436 C22.08284,14.136036 22.1103429,14.7686034 21.7371505,15.1757223 C21.3639581,15.5828413 20.7313908,15.6103443 20.3242718,15.2371519 L15.0300721,10.3841355 L9.70710318,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(14.999999, 11.999997) scale(1, -1) rotate(90.000000) translate(-14.999999, -11.999997)"></path>
                        </g>
                     </svg>
                     <!--end::Svg Icon-->
                  </span>
                  <span class="text-white">Хостинг Minecraft серверов</span>
               </div>
               <div class="d-flex mb-5">
                  <span class="svg-icon svg-icon-md svg-icon-white flex-shrink-0 mr-3">
                     <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Arrow-right.svg-->
                     <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                           <polygon points="0 0 24 0 24 24 0 24"></polygon>
                           <rect fill="#000000" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000)" x="11" y="5" width="2" height="14" rx="1"></rect>
                           <path d="M9.70710318,15.7071045 C9.31657888,16.0976288 8.68341391,16.0976288 8.29288961,15.7071045 C7.90236532,15.3165802 7.90236532,14.6834152 8.29288961,14.2928909 L14.2928896,8.29289093 C14.6714686,7.914312 15.281055,7.90106637 15.675721,8.26284357 L21.675721,13.7628436 C22.08284,14.136036 22.1103429,14.7686034 21.7371505,15.1757223 C21.3639581,15.5828413 20.7313908,15.6103443 20.3242718,15.2371519 L15.0300721,10.3841355 L9.70710318,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(14.999999, 11.999997) scale(1, -1) rotate(90.000000) translate(-14.999999, -11.999997)"></path>
                        </g>
                     </svg>
                     <!--end::Svg Icon-->
                  </span>
                  <span class="text-white">Хостинг CS серверов</span>
               </div>
               <div class="d-flex">
                  <span class="svg-icon svg-icon-md svg-icon-white flex-shrink-0 mr-3">
                     <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Arrow-right.svg-->
                     <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                        <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                           <polygon points="0 0 24 0 24 24 0 24"></polygon>
                           <rect fill="#000000" opacity="0.3" transform="translate(12.000000, 12.000000) rotate(-90.000000) translate(-12.000000, -12.000000)" x="11" y="5" width="2" height="14" rx="1"></rect>
                           <path d="M9.70710318,15.7071045 C9.31657888,16.0976288 8.68341391,16.0976288 8.29288961,15.7071045 C7.90236532,15.3165802 7.90236532,14.6834152 8.29288961,14.2928909 L14.2928896,8.29289093 C14.6714686,7.914312 15.281055,7.90106637 15.675721,8.26284357 L21.675721,13.7628436 C22.08284,14.136036 22.1103429,14.7686034 21.7371505,15.1757223 C21.3639581,15.5828413 20.7313908,15.6103443 20.3242718,15.2371519 L15.0300721,10.3841355 L9.70710318,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(14.999999, 11.999997) scale(1, -1) rotate(90.000000) translate(-14.999999, -11.999997)"></path>
                        </g>
                     </svg>
                     <!--end::Svg Icon-->
                  </span>
                  <span class="text-white">Хостинг MTA серверов</span>
               </div>               
            </div>
         </div>
      </div>
   </div>
   <!--end::Engage Widget 3-->
</div>
<?php foreach($news as $item): ?> 
<div class="col-xl-12">
   <div class="card card-custom mb-4">
      <div class="card-body">
       <div class="d-flex align-items-center">
         <div class="symbol symbol-45 symbol-light mr-5">
            <span class="symbol-label">
              <span class="svg-icon svg-icon-lg svg-icon-primary">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                  <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                     <rect x="0" y="0" width="24" height="24"></rect>
                     <path d="M8,3 L8,3.5 C8,4.32842712 8.67157288,5 9.5,5 L14.5,5 C15.3284271,5 16,4.32842712 16,3.5 L16,3 L18,3 C19.1045695,3 20,3.8954305 20,5 L20,21 C20,22.1045695 19.1045695,23 18,23 L6,23 C4.8954305,23 4,22.1045695 4,21 L4,5 C4,3.8954305 4.8954305,3 6,3 L8,3 Z" fill="#000000" opacity="0.3"></path>
                     <path d="M11,2 C11,1.44771525 11.4477153,1 12,1 C12.5522847,1 13,1.44771525 13,2 L14.5,2 C14.7761424,2 15,2.22385763 15,2.5 L15,3.5 C15,3.77614237 14.7761424,4 14.5,4 L9.5,4 C9.22385763,4 9,3.77614237 9,3.5 L9,2.5 C9,2.22385763 9.22385763,2 9.5,2 L11,2 Z" fill="#000000"></path>
                     <rect fill="#000000" opacity="0.3" x="7" y="10" width="5" height="2" rx="1"></rect>
                     <rect fill="#000000" opacity="0.3" x="7" y="14" width="9" height="2" rx="1"></rect>
                  </g>
                </svg>
              </span>
            </span>
         </div>
         <div class="d-flex flex-column flex-grow-1">
            <a href="/news/view/index/<?echo $item['news_id']?>" class="text-dark-75 text-hover-primary mb-1 font-size-lg font-weight-bolder"> <?php echo $item['news_title'] ?></a>
            <div class="d-flex">
              <div class="d-flex align-items-center pr-5" data-toggle="tooltip" title="" data-placement="right" data-original-title="Дата публикации">
                <span class="svg-icon svg-icon-md svg-icon-primary pr-1">
                  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                     <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                       <rect x="0" y="0" width="24" height="24"></rect>
                       <path d="M12,22 C7.02943725,22 3,17.9705627 3,13 C3,8.02943725 7.02943725,4 12,4 C16.9705627,4 21,8.02943725 21,13 C21,17.9705627 16.9705627,22 12,22 Z" fill="#000000" opacity="0.3"></path>
                       <path d="M11.9630156,7.5 L12.0475062,7.5 C12.3043819,7.5 12.5194647,7.69464724 12.5450248,7.95024814 L13,12.5 L16.2480695,14.3560397 C16.403857,14.4450611 16.5,14.6107328 16.5,14.7901613 L16.5,15 C16.5,15.2109164 16.3290185,15.3818979 16.1181021,15.3818979 C16.0841582,15.3818979 16.0503659,15.3773725 16.0176181,15.3684413 L11.3986612,14.1087258 C11.1672824,14.0456225 11.0132986,13.8271186 11.0316926,13.5879956 L11.4644883,7.96165175 C11.4845267,7.70115317 11.7017474,7.5 11.9630156,7.5 Z" fill="#000000"></path>
                     </g>
                  </svg>
                </span>
                <span class="text-muted font-weight-bold"><?php echo date("d.m.Y в H:i", strtotime($item['news_date_add'])) ?></span>
              </div>
            </div>
         </div>
       </div>
       <div class="pt-3">
         <p class="text-dark-75 font-size-lg font-weight-normal pt-5 mb-2">  <?php echo $item['news_title'] ?></p>
       </div>
      </div>
   </div>
</div>
<?php endforeach; ?>
<?php if(empty($news)): ?>
<div class="col-xl-12">
   <div class="alert alert-custom alert-primary fade show" role="alert">
      <div class="alert-icon"><i class="flaticon-warning"></i></div>
      <div class="alert-text">К сожалению, на данный момент на хостинге нет новостей</div>
      <div class="alert-close">
         <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="ki ki-close"></i></span>
         </button>
      </div>
   </div>   
</div>               
<?php endif; ?>                                          
</div>
</div>
</div>
</div>
<?php echo $footer ?>
