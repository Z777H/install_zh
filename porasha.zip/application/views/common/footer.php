<div class="footer bg-white py-4 d-flex flex-lg-column" id="kt_footer">
	<div class="container d-flex flex-column flex-md-row align-items-center justify-content-between">
		<div class="text-dark order-2 order-md-1">
			<span class="text-muted font-weight-bold mr-2">2023©</span>
			<a href="/main/index" target="_blank" class="text-dark-75 text-hover-primary">Все права защищены!</a>
		</div>
		<div class="nav nav-dark order-1 order-md-2">
			<a data-toggle="modal" data-target="#contacts_modal" class="nav-link pr-3 pl-0">Контакты</a>
		</div>
	</div>
</div>

<div class="modal fade show" id="contacts_modal" tabindex="-1" role="dialog" data-backdrop="static">
			<div class="modal-dialog modal-md modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h6 class="modal-title">Контакты</h6>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<i aria-hidden="true" class="ki ki-close"></i>
						</button>
					</div>
					<div class="modal-body">
						<p>Для связи с нами, можете воспользоваться данными контактами:</p>
						<p><b>Почта:</b> <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="235946514c0d4b4c50574a4d44635a424d47465b0d5156">[email&#160;protected]</a></p>
						<p><b>Моб. телефон:</b> +7 (831) 282-33-22</p>
						<p><b>Сообщество ВКонтакте:</b> <a href="https://vk.com/public<?php echo $public ?>" data-link="folow_new">Перейти</a></p>
						<p><b>САЙТ ДУРКИ:</b> <a href="https://namedow.ru/" data-link="folow_new">Перейти</a></p>
					</div>
				</div>
			</div>
		</div>
		<div class="modal fade show" id="language" tabindex="-1" role="dialog" data-backdrop="static">
			<div class="modal-dialog modal-md modal-dialog-centered" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h6 class="modal-title">Диалог для смены (языка)</h6>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<i aria-hidden="true" class="ki ki-close"></i>
						</button>
					</div>
					<div class="modal-body">
					<button type="submit" alt="ru" data-google-lang="ru" class="btn btn-light-success font-weight-bold">Русский</button>
					<button type="submit" alt="en" data-google-lang="en" class="btn btn-sm btn-light-danger font-weight-bolder py-3 px-5">Англиский</button>
					<button type="submit" alt="uk" data-google-lang="uk" class="btn btn-sm btn-light-warning font-weight-bolder py-3 px-5">Украинский</button>
					</div>
				</div>
			</div>
		</div>
		<script>
       function language(language_name) {
               $('.menu-item').removeClass('menu-item-here menu-item-active');
               if (language_name == 'ru') {
                  Cookies.set('language', 'ru', {
                     expires: 365,
                     path: '/'
                  });
                  toastr.success("Вы успешно установили Русский язык!");
               } else if (language_name == 'en') {
                  Cookies.set('language', 'en', {
                     expires: 365,
                     path: '/'
                  });
                  toastr.success("You have successfully installed the English language!");
               }
               if (language_name == 'ru' || language_name == 'en') {
                  $('#' + language_name).addClass('menu-item-active');
                  setTimeout("reload()", 1500);
               } else {
                  toastr.error("Fatal error!");
               }
            }
   </script>
<script>
	toastr.options = {
	"closeButton": true,
	"debug": false,
	"newestOnTop": false,
	"progressBar": true,
	"positionClass": "toast-top-right",
	"preventDuplicates": false,
	"onclick": null,
	"showDuration": "300",
	"hideDuration": "1000",
	"timeOut": "3500",
	"extendedTimeOut": "3000",
	"showEasing": "swing",
	"hideEasing": "linear",
	"showMethod": "fadeIn",
	"hideMethod": "fadeOut"   
	};
</script>
<script type="text/javascript">
	$(document).ready(
		function get() {
			setTimeout(getstatus('online'), 105000);
			setTimeout(get, 35000);
		}
	);
	function getstatus(action) {
		$.ajax({ 
			url: '/main/index/getstatus/'+action,
			dataType: 'text',
			success: function(data) {
				data = $.parseJSON(data);
				switch(data.status) {
					case 'error':
						toastr.error(data.error);
						$('#controlBtns button').prop('disabled', false);
						break;
					case 'online':
						console.info(data.online); 
						$("#online").html(data.online_usr)
						break
				}
			},
		});
	}
</script>